import math
import logging

from einops import rearrange,repeat
import torch
import torch.nn as nn
from torch.nn import functional as F
from transformers.models.deberta.modeling_deberta import XSoftmax
from transformers.models.deberta.modeling_deberta import StableDropout

logger = logging.getLogger(__name__)

class GPTConfig:
    """ base GPT config, params common to all GPT versions """
    embd_pdrop = 0.1
    resid_pdrop = 0.1
    attn_pdrop = 0.1
    def __init__(self, vocab_size, block_size, **kwargs):
        self.vocab_size = vocab_size
        self.block_size = block_size
        if "dropout" in kwargs:
            self.embd_pdrop = kwargs["dropout"]
            self.resid_pdrop = kwargs["dropout"]
            self.attn_pdrop = kwargs["dropout"]
        for k,v in kwargs.items():
            setattr(self, k, v)
        


class CausalSelfAttention(nn.Module):
    """
    A vanilla multi-head masked self-attention layer with a projection at the end.
    It is possible to use torch.nn.MultiheadAttention here but I am including an
    explicit implementation here to show that there is nothing too scary here.
    """

    def __init__(self, config):
        super().__init__()
        assert config.n_embd % config.n_head == 0
        # key, query, value projections for all heads
        self.key = nn.Linear(config.n_embd, config.n_embd)
        self.query = nn.Linear(config.n_embd, config.n_embd)
        self.value = nn.Linear(config.n_embd, config.n_embd)
        # regularization
        self.attn_drop = nn.Dropout(config.attn_pdrop)
        self.resid_drop = nn.Dropout(config.resid_pdrop)
        # output projection
        self.proj = nn.Linear(config.n_embd, config.n_embd)
        # causal mask to ensure that attention is only applied to the left in the input sequence
        num = int(bool(config.num_props)) + int(config.scaffold_maxlen)
        # num = 1
        self.register_buffer("mask", torch.tril(torch.ones(config.block_size + num, config.block_size + num))
                                     .view(1, 1, config.block_size + num, config.block_size + num))

        self.rope = config.position == 'rope'
        self.n_head = config.n_head

    def forward(self, x):
        B, T, C = x.size()

        # calculate query, key, values for all heads in batch and move head forward to be the batch dim
        k = self.key(x).view(B, T, self.n_head, C // self.n_head).transpose(1, 2) # (B, nh, T, hs)
        q = self.query(x).view(B, T, self.n_head, C // self.n_head).transpose(1, 2) # (B, nh, T, hs)
        v = self.value(x).view(B, T, self.n_head, C // self.n_head).transpose(1, 2) # (B, nh, T, hs)

        if self.rope == True:
            y, attn = self.attention(q, k, v, mask=self.mask[:,:,:T,:T], dropout=self.attn_drop, use_RoPE=True)
            y = y.transpose(1, 2).contiguous().view(B, T, C)
            return self.resid_drop(self.proj(y)), attn
        else:
            # causal self-attention; Self-attend: (B, nh, T, hs) x (B, nh, hs, T) -> (B, nh, T, T)
            att = (q @ k.transpose(-2, -1)) * (1.0 / math.sqrt(k.size(-1)))
            att = att.masked_fill(self.mask[:,:,:T,:T] == 0, float('-inf'))
            att = F.softmax(att, dim=-1)
            attn_save = att
            att = self.attn_drop(att)
            y = att @ v # (B, nh, T, T) x (B, nh, T, hs) -> (B, nh, T, hs)
            y = y.transpose(1, 2).contiguous().view(B, T, C) # re-assemble all head outputs side by side

            # output projection
            y = self.resid_drop(self.proj(y))
            return y, attn_save


    def sinusoidal_position_embedding(self,batch_size, nums_head, max_len, output_dim, device):
        # (max_len, 1)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(-1)
        # (output_dim//2)
        ids = torch.arange(0, output_dim // 2, dtype=torch.float)  # 即公式里的i, i的范围是 [0,d/2]
        theta = torch.pow(10000, -2 * ids / output_dim)

        # (max_len, output_dim//2)
        embeddings = position * theta  # 即公式里的：pos / (10000^(2i/d))

        # (max_len, output_dim//2, 2)
        embeddings = torch.stack([torch.sin(embeddings), torch.cos(embeddings)], dim=-1)

        # (bs, head, max_len, output_dim//2, 2)
        embeddings = embeddings.repeat((batch_size, nums_head, *([1] * len(embeddings.shape))))  # 在bs维度重复，其他维度都是1不重复

        # (bs, head, max_len, output_dim)
        # reshape后就是：偶数sin, 奇数cos了
        embeddings = torch.reshape(embeddings, (batch_size, nums_head, max_len, output_dim))
        embeddings = embeddings.to(device)
        return embeddings


    def RoPE(self, q, k):
        # q,k: (bs, head, max_len, output_dim)
        batch_size = q.shape[0]
        nums_head = q.shape[1]
        max_len = q.shape[2]
        output_dim = q.shape[-1]

        # (bs, head, max_len, output_dim)
        pos_emb = self.sinusoidal_position_embedding(batch_size, nums_head, max_len, output_dim, q.device)


        # cos_pos,sin_pos: (bs, head, max_len, output_dim)
        # 看rope公式可知，相邻cos，sin之间是相同的，所以复制一遍。如(1,2,3)变成(1,1,2,2,3,3)
        cos_pos = pos_emb[...,  1::2].repeat_interleave(2, dim=-1)  # 将奇数列信息抽取出来也就是cos 拿出来并复制
        sin_pos = pos_emb[..., ::2].repeat_interleave(2, dim=-1)  # 将偶数列信息抽取出来也就是sin 拿出来并复制

        # q,k: (bs, head, max_len, output_dim)
        q2 = torch.stack([-q[..., 1::2], q[..., ::2]], dim=-1)
        q2 = q2.reshape(q.shape)  # reshape后就是正负交替了

        # 更新qw, *对应位置相乘
        q = q * cos_pos + q2 * sin_pos

        k2 = torch.stack([-k[..., 1::2], k[..., ::2]], dim=-1)
        k2 = k2.reshape(k.shape)
        # 更新kw, *对应位置相乘
        k = k * cos_pos + k2 * sin_pos

        return q, k


    def attention(self, q, k, v, mask=None, dropout=None, use_RoPE=True):
        # q.shape: (bs, head, seq_len, dk)
        # k.shape: (bs, head, seq_len, dk)
        # v.shape: (bs, head, seq_len, dk)

        if use_RoPE:
            q, k = self.RoPE(q, k)

        d_k = k.size()[-1]

        att_logits = torch.matmul(q, k.transpose(-2, -1))  # (bs, head, seq_len, seq_len)
        att_logits /= math.sqrt(d_k)

        if mask is not None:
            att_logits = att_logits.masked_fill(mask == 0, -torch.inf)  # mask掉为0的部分，设为无穷大

        att_scores = F.softmax(att_logits, dim=-1)  # (bs, head, seq_len, seq_len)
        att_save = att_scores
        if dropout is not None:
            att_scores = dropout(att_scores)

        # (bs, head, seq_len, seq_len) * (bs, head, seq_len, dk) = (bs, head, seq_len, dk)
        return torch.matmul(att_scores, v), att_save

class FixedAbsolutePositionEmbedding(nn.Module):
    def __init__(self, config):
        super().__init__()

        self.position_embedding_type = config.position  # 位置编码方式
        self.is_absolute = True

        # 根据隐藏层大小计算频率
        inv_freq = 1. / (10000 ** (torch.arange(0, config.n_embd, 2, dtype=torch.float) / config.n_embd))
        position = torch.arange(config.n_embd, dtype=torch.float)
        sinusoid_inp = torch.einsum('i,j -> ij', position, inv_freq)
        embeddings = torch.cat((sinusoid_inp.sin(), sinusoid_inp.cos()), dim=-1)
        self.register_buffer('embeddings', embeddings)

    def forward_fixed(self, x):
        # 固定位置编码方式下的前向传播
        return x + self.embeddings[None, :x.size(1), :x.size(2)]


    def _forward(self, x):
        # 根据位置编码方式选择前向传播方法
        if self.position_embedding_type == 'fixed':
            return self.forward_fixed(x)

    def forward(self, x):
        # 处理输入的维度
        if x.dim() == 3:
            return self._forward(x)
        elif x.dim() == 4:
            h = x.size(1)
            x = rearrange(x, 'b h l d -> (b h) l d')
            x = self._forward(x)
            x = rearrange(x, '(b h) l d -> b h l d', h=h)
            return x

class GeGLU(nn.Module):
    def __init__(self, in_features, out_features):
        super(GeGLU, self).__init__()
        self.linear1 = nn.Linear(in_features, out_features)
        self.linear2 = nn.Linear(in_features, out_features)

    def forward(self, x):
        return self.linear1(x) * F.gelu(self.linear2(x))
    
    
class Block(nn.Module):
    """ an unassuming Transformer block """

    def __init__(self, config):
        super().__init__()
        self.ln1 = nn.LayerNorm(config.n_embd)
        self.ln2 = nn.LayerNorm(config.n_embd)
        self.attn = CausalSelfAttention(config)
        self.alpha = math.pow(2 * config.n_layer,0.25)
        self.ln_methods = config.ln
        
        if config.activation == 'gelu':
            activation = nn.GELU()
        elif config.activation == 'relu':
            activation = nn.ReLU()
        elif config.activation == 'geglu':
            activation = GeGLU(4 * config.n_embd, 4 * config.n_embd)
        
        self.mlp = nn.Sequential(
            nn.Linear(config.n_embd, 4 * config.n_embd),
            activation,
            nn.Linear(4 * config.n_embd, config.n_embd),
            nn.Dropout(config.resid_pdrop),
        )


    def forward(self, x):
        if self.ln_methods == 'deep':
            y, attn = self.attn(x)
            x = self.ln1(self.alpha * x + y)
            x = self.ln2(self.alpha * x + self.mlp(x))
        elif self.ln_methods == 'pre':
            x = self.ln1(x)
            y, attn = self.attn(x)
            x = self.ln2(x + y)
            x = x + self.mlp(x)
        return x, attn
        

class GPT(nn.Module):
    """  the full GPT language model, with a context size of block_size """

    def __init__(self, config, encoder = False):
        super().__init__()

        # input embedding stem
        self.encoder = encoder
        if self.encoder:
            self.transformer = nn.Transformer(d_model=256,num_encoder_layers=8, num_decoder_layers=8, dim_feedforward=1024, batch_first=True)
        self.config = config
        self.tok_emb = nn.Embedding(config.vocab_size, config.n_embd)
        self.type_emb = nn.Embedding(2, config.n_embd)
        if config.num_props:
            self.prop_nn = nn.Linear(config.num_props, config.n_embd)

        self.ln_methods = config.ln
        self.beta = math.pow(8 * config.n_layer,-0.25)  # beta参数，用于缩放梯度
        self.position_embeddings = FixedAbsolutePositionEmbedding(config)
        self.drop = nn.Dropout(config.embd_pdrop)
        # transformer
        self.blocks = nn.Sequential(*[Block(config) for _ in range(config.n_layer)])
        # decoder head
        self.ln_f = nn.LayerNorm(config.n_embd)
        self.head = nn.Linear(config.n_embd, config.vocab_size, bias=False)
        
        self.block_size = config.block_size

        self.apply(self._init_weights)
        
        logger.info("number of parameters: %e", sum(p.numel() for p in self.parameters()))

    def get_block_size(self):
        return self.block_size

    def _init_weights(self, module):
        if self.ln_methods == 'deep':
            if isinstance(module, nn.Linear):
                # 使用Xavier正态分布初始化线性层的权重，增益为self.beta
                nn.init.xavier_normal_(module.weight, gain=self.beta)
                if module.bias is not None:
                    # 初始化线性层的偏置为0
                    nn.init.zeros_(module.bias)
            elif isinstance(module, CausalSelfAttention):
                # 使用Xavier正态分布初始化多头注意力机制的权重，增益为1
                q_weight, k_weight, v_weight = module.query.weight, module.key.weight, module.value.weight
                nn.init.xavier_normal_(q_weight, gain=1)
                nn.init.xavier_normal_(k_weight, gain=1)
                # 使用Xavier正态分布初始化多头注意力机制的值权重，增益为self.beta
                nn.init.xavier_normal_(v_weight, gain=self.beta)
                # 使用Xavier正态分布初始化多头注意力机制的输出投影权重，增益为self.beta
                nn.init.xavier_normal_(module.proj.weight, gain=self.beta)
            elif isinstance(module, nn.LayerNorm):
                # 初始化LayerNorm层的权重为1，偏置为0
                nn.init.constant_(module.weight, 1)
                nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.Embedding):
                # 使用均值为0，标准差为0.01的正态分布初始化嵌入层的权重
                nn.init.normal_(module.weight, mean=0, std=0.01)
            
        else:
            if isinstance(module, (nn.Linear, nn.Embedding)):
                module.weight.data.normal_(mean=0.0, std=0.02)
                if isinstance(module, nn.Linear) and module.bias is not None:
                    module.bias.data.zero_()
            elif isinstance(module, nn.LayerNorm):
                module.bias.data.zero_()
                module.weight.data.fill_(1.0)

    def configure_optimizers(self, train_config):
        # separate out all parameters to those that will and won't experience regularizing weight decay
        decay = set()
        no_decay = set()
        whitelist_weight_modules = (torch.nn.Linear,torch.nn.MultiheadAttention)
        blacklist_weight_modules = (torch.nn.LayerNorm, torch.nn.Embedding)
        for mn, m in self.named_modules():
            for pn, p in m.named_parameters():
                fpn = '%s.%s' % (mn, pn) if mn else pn # full param name
                
                if pn.endswith('bias') or ('bias' in pn):
                    # all biases will not be decayed
                    no_decay.add(fpn)
                elif (pn.endswith('weight') or ('weight' in pn)) and isinstance(m, whitelist_weight_modules):
                    # weights of whitelist modules will be weight decayed
                    decay.add(fpn)
                elif pn.endswith('weight') and isinstance(m, blacklist_weight_modules):
                    # weights of blacklist modules will NOT be weight decayed
                    no_decay.add(fpn)

        # special case the position embedding parameter in the root GPT module as not decayed
        # no_decay.add('pos_emb')

        # validate that we considered every parameter
        param_dict = {pn: p for pn, p in self.named_parameters()}
        inter_params = decay & no_decay
        union_params = decay | no_decay
        assert len(inter_params) == 0, "parameters %s made it into both decay/no_decay sets!" % (str(inter_params), )
        assert len(param_dict.keys() - union_params) == 0, "parameters %s were not separated into either decay/no_decay set!" \
                                                    % (str(param_dict.keys() - union_params), )

        # create the pytorch optimizer object
        optim_groups = [
            {"params": [param_dict[pn] for pn in sorted(list(decay))], "weight_decay": train_config.weight_decay},
            {"params": [param_dict[pn] for pn in sorted(list(no_decay))], "weight_decay": 0.0},
        ]
        optimizer = torch.optim.AdamW(optim_groups, lr=train_config.learning_rate, betas=train_config.betas)
        return optimizer

    def forward(self, idx, targets=None, prop = None, scaffold = None):
        b, t = idx.size()
        assert t <= self.block_size, "Cannot forward, model block size is exhausted."
        if self.config.num_props:
            assert prop.size(-1) == self.config.num_props, "Num_props should be equal to last dim of property vector"           

        # forward the GPT model
        token_embeddings = self.tok_emb(idx) # each index maps to a (learnable) vector
        type_embeddings = self.type_emb(torch.ones((b,t), dtype = torch.long, device = idx.device))
        if self.config.position == 'rope':
            x = self.drop(token_embeddings + type_embeddings)
        else:
            x = self.drop(self.position_embeddings(token_embeddings) + type_embeddings)
        x_save = x
        if self.config.num_props:
            type_embd = self.type_emb(torch.zeros((b, 1), dtype = torch.long, device = idx.device))
            if prop.ndim == 2:
                p = self.prop_nn(prop.unsqueeze(1))    # for single property
            else:
                p = self.prop_nn(prop)    # for multiproperty
            p += type_embd
            x = torch.cat([p, x], 1)
        
        if self.config.scaffold:
            type_embd = self.type_emb(torch.zeros((b, 1), dtype = torch.long, device = idx.device))
            
            scaffold_embeds = self.tok_emb(scaffold)     # .mean(1, keepdim = True)
            if not self.config.position == 'rope':scaffold_embeds = self.position_embeddings(scaffold_embeds)
            scaffold_embeds += type_embd
            x = torch.cat([scaffold_embeds, x], 1)

        attn_maps = []
        
        if self.encoder:
            src = x[:,:-x_save.size(1)]
            tgt = x_save
            sz = tgt.size(1)
            tgt_mask = torch.triu(torch.full((sz, sz), float('-inf'), device=idx.device), diagonal=1)
            x = self.transformer(src,tgt,tgt_mask=tgt_mask)
        else:
            for layer in self.blocks:
                x, attn = layer(x)
                attn_maps.append(attn)

        x = self.ln_f(x)
        logits = self.head(x)

        if self.config.num_props and self.config.scaffold:
            num = int(bool(self.config.num_props)) + int(self.config.scaffold_maxlen)
        elif self.config.num_props:
            num = int(bool(self.config.num_props))
        elif self.config.scaffold:
            num = int(self.config.scaffold_maxlen) 
        else:
            num = 0
        if not self.encoder:
            logits = logits[:, num:, :]

        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.view(-1))

        return logits, loss, attn_maps # (num_layers, batch_size, num_heads, max_seq_len, max_seq_len)