if __name__ == "__main__":
    import os
    import subprocess
    import pandas as pd

    # 定义不同的n_blocks值
    n_blocks_values = [0, 1, 2, 3, 4, 5, 6, 7, 8]

    # 训练脚本的路径
    script_path = "train/transfer.py"
    # 模型权重的路径
    model_path = "train/cond_gpt/weights/sca_rope/epoch_10_sca_rope.pt"
    # 运行名称前缀
    run_name_prefix = "transfer_sca_rope_att_"
    # 迭代不同的n_blocks值
    for n_blocks in n_blocks_values:
        run_name = run_name_prefix + str(n_blocks)
        # 构建命令行命令
        command = [
            "python", script_path,
            "--run_name", run_name,
            "--model_path", model_path,
            "--n_blocks", str(n_blocks),
            "--position","rope",
            # "--freeze_decoder_layers",str(n_blocks),
            # "--freeze_encoder_layers",str(n_blocks),
            "--scaffold",
            # "--encoder",
            "--freeze_attention"
        ]
        # 执行命令
        result = subprocess.run(command, capture_output=True, text=True)
        print(n_blocks)